print([1,2,3,4])
get=input()
get.append('i get')
print(get)